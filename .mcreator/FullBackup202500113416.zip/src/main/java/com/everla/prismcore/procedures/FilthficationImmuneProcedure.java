package com.everla.prismcore.procedures;

import net.minecraftforge.eventbus.api.Event;

import com.everla.prismcore.init.PrismcoreModMobEffects;

@Mod.EventBusSubscriber
public class FilthficationImmuneProcedure {
	@SubscribeEvent
	public static void onEntityAttacked(LivingAttackEvent event) {
		if (event != null && event.getEntity() != null) {
			execute(event, event.getSource(), event.getEntity());
		}
	}

	public static void execute(DamageSource damagesource, Entity entity) {
		execute(null, damagesource, entity);
	}

	private static void execute(@Nullable Event event, DamageSource damagesource, Entity entity) {
		if (damagesource == null || entity == null)
			return;
		if ((entity instanceof LivingEntity _livEnt && _livEnt.hasEffect(PrismcoreModMobEffects.FILTHFICATION.get()) ? _livEnt.getEffect(PrismcoreModMobEffects.FILTHFICATION.get()).getDuration() : 0) >= 1) {
			if (damagesource.is(TagKey.create(Registries.DAMAGE_TYPE, new ResourceLocation("kubejs:filth_immune")))) {
				if (event != null && event.isCancelable()) {
					event.setCanceled(true);
				} else if (event != null && event.hasResult()) {
					event.setResult(Event.Result.DENY);
				}
			}
		}
	}
}
