
package com.everla.prismcore.potion;

public class HasBeenFoundMobEffect extends MobEffect {
	public HasBeenFoundMobEffect() {
		super(MobEffectCategory.BENEFICIAL, -65536);
	}

	@Override
	public boolean isDurationEffectTick(int duration, int amplifier) {
		return true;
	}
}
