
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package com.everla.prismcore.init;

import com.everla.prismcore.client.particle.OverclockParticle;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class PrismcoreModParticles {
	@SubscribeEvent
	public static void registerParticles(RegisterParticleProvidersEvent event) {
		event.registerSpriteSet(PrismcoreModParticleTypes.OVERCLOCK.get(), OverclockParticle::provider);
	}
}
