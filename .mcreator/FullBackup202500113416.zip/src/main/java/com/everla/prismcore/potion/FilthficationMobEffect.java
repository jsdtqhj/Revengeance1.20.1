
package com.everla.prismcore.potion;

public class FilthficationMobEffect extends MobEffect {
	public FilthficationMobEffect() {
		super(MobEffectCategory.NEUTRAL, -10092544);
	}

	@Override
	public boolean isDurationEffectTick(int duration, int amplifier) {
		return true;
	}
}
