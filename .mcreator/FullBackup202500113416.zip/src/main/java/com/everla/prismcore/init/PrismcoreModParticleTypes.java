
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package com.everla.prismcore.init;

import com.everla.prismcore.PrismcoreMod;

public class PrismcoreModParticleTypes {
	public static final DeferredRegister<ParticleType<?>> REGISTRY = DeferredRegister.create(ForgeRegistries.PARTICLE_TYPES, PrismcoreMod.MODID);
	public static final RegistryObject<SimpleParticleType> OVERCLOCK = REGISTRY.register("overclock", () -> new SimpleParticleType(false));
}
