
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package com.everla.prismcore.init;

import com.everla.prismcore.PrismcoreMod;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class PrismcoreModAttributes {
	public static final DeferredRegister<Attribute> REGISTRY = DeferredRegister.create(ForgeRegistries.ATTRIBUTES, PrismcoreMod.MODID);
	public static final RegistryObject<Attribute> RAGE_LEVEL = REGISTRY.register("rage_level", () -> new RangedAttribute("attribute.prismcore.rage_level", 0, -1, 100).setSyncable(true));
	public static final RegistryObject<Attribute> ADRENALINE_LEVEL = REGISTRY.register("adrenaline_level", () -> new RangedAttribute("attribute.prismcore.adrenaline_level", 0, -1, 10000).setSyncable(true));

	@SubscribeEvent
	public static void addAttributes(EntityAttributeModificationEvent event) {
		event.add(EntityType.PLAYER, RAGE_LEVEL.get());
		event.add(EntityType.PLAYER, ADRENALINE_LEVEL.get());
	}

	@Mod.EventBusSubscriber
	public static class PlayerAttributesSync {
		@SubscribeEvent
		public static void playerClone(PlayerEvent.Clone event) {
			Player oldPlayer = event.getOriginal();
			Player newPlayer = event.getEntity();
			newPlayer.getAttribute(RAGE_LEVEL.get()).setBaseValue(oldPlayer.getAttribute(RAGE_LEVEL.get()).getBaseValue());
			newPlayer.getAttribute(ADRENALINE_LEVEL.get()).setBaseValue(oldPlayer.getAttribute(ADRENALINE_LEVEL.get()).getBaseValue());
		}
	}
}
