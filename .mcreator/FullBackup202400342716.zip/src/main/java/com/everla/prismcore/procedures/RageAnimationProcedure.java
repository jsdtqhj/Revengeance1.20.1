package com.everla.prismcore.procedures;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.eventbus.api.Event;
import net.minecraftforge.event.TickEvent;

import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.CommandSource;

import javax.annotation.Nullable;

import com.everla.prismcore.init.PrismcoreModMobEffects;
import com.everla.prismcore.init.PrismcoreModAttributes;

@Mod.EventBusSubscriber
public class RageAnimationProcedure {
	@SubscribeEvent
	public static void onPlayerTick(TickEvent.PlayerTickEvent event) {
		if (event.phase == TickEvent.Phase.END) {
			execute(event, event.player);
		}
	}

	public static void execute(Entity entity) {
		execute(null, entity);
	}

	private static void execute(@Nullable Event event, Entity entity) {
		if (entity == null)
			return;
		if (entity.getPersistentData().getBoolean("enabledRage") == true) {
			if ((entity instanceof LivingEntity _livingEntity1 && _livingEntity1.getAttributes().hasAttribute(PrismcoreModAttributes.RAGE_LEVEL.get()) ? _livingEntity1.getAttribute(PrismcoreModAttributes.RAGE_LEVEL.get()).getValue() : 0) >= 1) {
				if (entity instanceof LivingEntity _livingEntity3 && _livingEntity3.getAttributes().hasAttribute(PrismcoreModAttributes.RAGE_LEVEL.get()))
					_livingEntity3.getAttribute(PrismcoreModAttributes.RAGE_LEVEL.get())
							.setBaseValue(((entity instanceof LivingEntity _livEnt && _livEnt.hasEffect(PrismcoreModMobEffects.RAGE.get()) ? _livEnt.getEffect(PrismcoreModMobEffects.RAGE.get()).getDuration() : 0) / 1.8));
			} else if ((entity instanceof LivingEntity _livingEntity4 && _livingEntity4.getAttributes().hasAttribute(PrismcoreModAttributes.RAGE_LEVEL.get())
					? _livingEntity4.getAttribute(PrismcoreModAttributes.RAGE_LEVEL.get()).getValue()
					: 0) < 1) {
				if (entity instanceof LivingEntity _livingEntity5 && _livingEntity5.getAttributes().hasAttribute(PrismcoreModAttributes.RAGE_LEVEL.get()))
					_livingEntity5.getAttribute(PrismcoreModAttributes.RAGE_LEVEL.get()).setBaseValue(0);
				entity.getPersistentData().putBoolean("enabledRage", false);
				entity.getPersistentData().putBoolean("fullRage", false);
			}
		}
		if ((entity instanceof LivingEntity _livingEntity8 && _livingEntity8.getAttributes().hasAttribute(PrismcoreModAttributes.RAGE_LEVEL.get()) ? _livingEntity8.getAttribute(PrismcoreModAttributes.RAGE_LEVEL.get()).getValue() : 0) == 100) {
			if (!(entity.getPersistentData().getBoolean("fullRage") == true)) {
				{
					Entity _ent = entity;
					if (!_ent.level().isClientSide() && _ent.getServer() != null) {
						_ent.getServer().getCommands().performPrefixedCommand(new CommandSourceStack(CommandSource.NULL, _ent.position(), _ent.getRotationVector(), _ent.level() instanceof ServerLevel ? (ServerLevel) _ent.level() : null, 4,
								_ent.getName().getString(), _ent.getDisplayName(), _ent.level().getServer(), _ent), "playsound prismcore:rage_full player @s");
					}
				}
				entity.getPersistentData().putBoolean("fullRage", true);
			}
		}
	}
}
