
/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package com.everla.prismcore.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.effect.MobEffect;

import com.everla.prismcore.potion.RageMobEffect;
import com.everla.prismcore.potion.HasBeenFoundMobEffect;
import com.everla.prismcore.potion.FilthficationMobEffect;
import com.everla.prismcore.potion.AdrenalineMobEffect;
import com.everla.prismcore.PrismcoreMod;

public class PrismcoreModMobEffects {
	public static final DeferredRegister<MobEffect> REGISTRY = DeferredRegister.create(ForgeRegistries.MOB_EFFECTS, PrismcoreMod.MODID);
	public static final RegistryObject<MobEffect> RAGE = REGISTRY.register("rage", () -> new RageMobEffect());
	public static final RegistryObject<MobEffect> ADRENALINE = REGISTRY.register("adrenaline", () -> new AdrenalineMobEffect());
	public static final RegistryObject<MobEffect> HAS_BEEN_FOUND = REGISTRY.register("has_been_found", () -> new HasBeenFoundMobEffect());
	public static final RegistryObject<MobEffect> FILTHFICATION = REGISTRY.register("filthfication", () -> new FilthficationMobEffect());
}
