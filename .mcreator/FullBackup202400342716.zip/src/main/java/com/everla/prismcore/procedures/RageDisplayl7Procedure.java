package com.everla.prismcore.procedures;

import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;

import com.everla.prismcore.init.PrismcoreModAttributes;

public class RageDisplayl7Procedure {
	public static boolean execute(Entity entity) {
		if (entity == null)
			return false;
		if ((entity instanceof LivingEntity _livingEntity0 && _livingEntity0.getAttributes().hasAttribute(PrismcoreModAttributes.RAGE_LEVEL.get()) ? _livingEntity0.getAttribute(PrismcoreModAttributes.RAGE_LEVEL.get()).getValue() : 0) >= 63) {
			return true;
		}
		return false;
	}
}
