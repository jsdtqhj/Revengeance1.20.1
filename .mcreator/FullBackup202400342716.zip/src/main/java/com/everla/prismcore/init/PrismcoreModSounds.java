
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package com.everla.prismcore.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.sounds.SoundEvent;
import net.minecraft.resources.ResourceLocation;

import com.everla.prismcore.PrismcoreMod;

public class PrismcoreModSounds {
	public static final DeferredRegister<SoundEvent> REGISTRY = DeferredRegister.create(ForgeRegistries.SOUND_EVENTS, PrismcoreMod.MODID);
	public static final RegistryObject<SoundEvent> RAGE_ACTIVITE = REGISTRY.register("rage_activite", () -> SoundEvent.createVariableRangeEvent(new ResourceLocation("prismcore", "rage_activite")));
	public static final RegistryObject<SoundEvent> RAGE_END = REGISTRY.register("rage_end", () -> SoundEvent.createVariableRangeEvent(new ResourceLocation("prismcore", "rage_end")));
	public static final RegistryObject<SoundEvent> RAGE_FULL = REGISTRY.register("rage_full", () -> SoundEvent.createVariableRangeEvent(new ResourceLocation("prismcore", "rage_full")));
	public static final RegistryObject<SoundEvent> ADRENALINE_ACTIVITE = REGISTRY.register("adrenaline_activite", () -> SoundEvent.createVariableRangeEvent(new ResourceLocation("prismcore", "adrenaline_activite")));
	public static final RegistryObject<SoundEvent> ADRENALINE_FULL = REGISTRY.register("adrenaline_full", () -> SoundEvent.createVariableRangeEvent(new ResourceLocation("prismcore", "adrenaline_full")));
	public static final RegistryObject<SoundEvent> ADRENALINE_CHARGE_BREAK = REGISTRY.register("adrenaline_charge_break", () -> SoundEvent.createVariableRangeEvent(new ResourceLocation("prismcore", "adrenaline_charge_break")));
}
