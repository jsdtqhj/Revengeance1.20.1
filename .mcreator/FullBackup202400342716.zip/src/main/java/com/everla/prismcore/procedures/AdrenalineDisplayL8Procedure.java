package com.everla.prismcore.procedures;

import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;

import com.everla.prismcore.init.PrismcoreModAttributes;

public class AdrenalineDisplayL8Procedure {
	public static boolean execute(Entity entity) {
		if (entity == null)
			return false;
		if ((entity instanceof LivingEntity _livingEntity0 && _livingEntity0.getAttributes().hasAttribute(PrismcoreModAttributes.ADRENALINE_LEVEL.get())
				? _livingEntity0.getAttribute(PrismcoreModAttributes.ADRENALINE_LEVEL.get()).getValue()
				: 0) >= 4662) {
			return true;
		}
		return false;
	}
}
